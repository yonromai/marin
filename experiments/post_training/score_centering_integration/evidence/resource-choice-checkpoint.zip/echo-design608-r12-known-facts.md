---
type: wiki-note
title: Keep PPO TIS score centering optional and probe it periodically
use_when: when changing score centering, periodic probes, or native head collection
  in MarinSkyRL
tags:
- design
- rl
- score-centering
resource: https://echo.oa.dev/wiki/608
---

## Context

[MarinSkyRL #968](https://github.com/marin-community/MarinSkyRL/pull/968) composes the [paper's correction](https://arxiv.org/html/2609.20807v1) with regular PPO and tokenwise truncated importance sampling (TIS). Native head collection and chat processing dominated the previously qualified adoption cost. Romain now authorizes an overhaul of our integration around vLLM `39e62869693c`, with its existing qualified hooks. New vLLM fork patches, upgrades, monkey patches and internal overrides are outside this goal. The older learning campaign remains stopped; [#996](https://github.com/marin-community/MarinSkyRL/pull/996) remains research.

## Decision

Keep SC disabled and continuous capture width zero by default. Positive width requests behavior heads and trainer rescoring; a separate flag applies the correction. Support regular PPO, one tokenwise TIS truncation rule, unpacked Megatron TP/CP/SP1 and local vLLM with exact chat tokens. Preserve existing DP/PP normalization and full-vocabulary probabilities. The additive row already integrates TIS and directional PPO clipping; applying the sampled action's TIS weight again changes its gradient. Outside the head, model old and behavior probabilities as proportional to current probabilities while preserving measured omitted mass.

Retain probe defaults `interval=10`, `topk=128`, `tokens_per_response=32`. Select one prompt group at startup and after the policy-step interval. Other groups keep chosen-token-only TIS. Capture the selected group's full response heads, then export at most 32 evenly spaced valid positions per response. The existing old-policy forward scores them. After finalizing advantages, summarize the would-be scalar correction and a separate unit-advantage correction, then remove probe tensors before the optimizer. SC-off optimizer inputs and updates remain unchanged. Rejection or masking can prevent observations; report consumed counts, coverage, source age and elapsed time. Unsupported configurations expose availability and reasons.

Use [composition around the public engine API](https://github.com/marin-community/MarinSkyRL/blob/87f13fcd82b4677545816e0789c685d10cf051a0/skyrl-train/skyrl_train/inference_engines/vllm/compact_chat.py) to collect flat numeric logprobs while ordinary vLLM chat serving renders and parses text. Suppress display logprobs only in the internal presentation request and carry owned arrays through native Ray metadata. Preserve public HTTP responses, exact tokens and messages, temperatures, masks, causal positions and per-token source versions. Keep the old 129-candidate collection for K128 and reproduce its display boundary so tied-head token IDs remain identical. Apply the existing chat score floor of -9999 before ID tie ordering, including chosen scores; raw generation is unchanged. This presentation floor differs from the SC modeled tail mass floor of 1e-6. Isolate concurrent requests, close generators on cancellation and align aborted/resumed chunks. Existing vLLM hooks and the vLLM dependency remain unchanged.

The pinned API still returns CPU primitive lists. Packing arrays, Ray, existing S3 rollout storage, CPU collation and transfer to learner GPUs remain. The authors' JAX collector buffers 32 decode steps on GPUs and reshards compact heads within a GPU pool used sequentially for sampling and training. Their under-1% result does not measure this vLLM handoff. K32 or lower SC frequency is not a substitute for optimizing the integration.

Fresh-source disagreement measures engine mismatch at matching weights; stale disagreement also contains weight drift. Unknown versions remain unknown. These pre-update probes have current=old and do not measure later PPO divergence. Unit-advantage diagnostics remain visible when actual advantages vanish. Scalar size and retained mass do not establish parameter-gradient accuracy or learning benefit.

## Validation and rollout

[Prior complete evidence](https://github.com/yonromai/marin/tree/af470a613fb0cc057c748d25ec681dd654821edb/experiments/post_training/score_centering_performance) measured 58.237-second ordinary cycles and 84.734-second SC cycles on Snowball, a 45.50% adoption cost. Its interval-ten probe model was 0.61% average overhead, with a descriptive interval of -0.17% to 1.40%. Those are historical serialized measurements, not costs established for the numeric transport.

[The current integration record](https://github.com/yonromai/marin/tree/03d5715226a493859b8995de411f0ef49da25029/experiments/post_training/score_centering_integration) preserves CPU formula/value/gradient and SC-off optimizer parity checks. Source `87f13fcd`, with the chat floor correction, passed 126 adapter checks and completed 35 Qwen updates. All four native comparisons were exact at temperatures 1.0/0.7 and lengths 128/4096. Independent references covered full-vocabulary normalization and causal positions. Thirty-two independent CPU tie cases and four actual pinned-formatter edge cases also matched. Its GPUs were released.

At the corrected source, CPU representation/pickle/client time for 4096 positions was 3.410 seconds with chat objects and 0.0651 with arrays. A cross-node 4096-token Qwen Ray echo carried 19.27 MB or 4.27 MB, taking about 0.68 or 0.018 seconds. These measurements exclude complete generation/storage/training and do not establish whole-cycle savings.

The complete matched RNO controls each applied 18 updates: one profiled warmup and two measured rotations per mode on the same five-node H100 geometry. Ordinary TIS cycles were 57.766 seconds with chat objects and 56.970 with arrays. SC cycles fell from 88.381 to 62.248 seconds, 29.57% shorter; adoption overhead fell from 53.00% to 9.27%. The descriptive log-time interval for shorter SC cycles is 19.51% to 38.38%; the new paired adoption interval is 7.40% to 11.17%. These small-sample descriptions cover one allocation per arm. Independent full-normalization references at both temperatures were within 1.91e-6.

Most savings appear in exclusive batch-admission wait, 71.69 to 45.42 seconds, including generation and handoff. The remaining SC cycle spends 1.12 seconds in batch assembly, 1.91 in old-policy scoring/preparation, 7.65 in training and 6.13 in weight publication. Nested timers and concurrent profiles overlap. Both arms retain three 256 MiB learner head matrices; no GPU memory reduction is established.

At interval ten, the controlled probe model gives 0.166% overhead and 570.64 seconds between observations, with a wide paired descriptive interval of -15.84% to 19.23%. It does not establish a sub-1% ceiling. A full probe captured 16384 engine tokens and exported 96 valid positions after masks. Cadence, K and position limits remain unchanged.

One candidate controls attempt timed out during handoff despite all 128 task requests finishing normally; its exact cause remains unresolved. The complete retry used unchanged source. Repeated external preemptions have interrupted fresh asynchronous baseline attempts. Both complete real-reward asynchronous results remain pending. The linked record preserves every allocation, incomplete outcome and finite plan revision. Controlled and asynchronous samples remain separate. Keep #968 a draft through asynchronous qualification, terminal current-head CI and the final goal review.

An existing AIME grader error interrupted another baseline. [Marin repair 5ef1e703](https://github.com/marin-community/marin/commit/5ef1e703d3bae94d510d8cf3f50d902958e10d20) rejects unsupported noncommutative constants before SymPy finiteness validation, without a broad exception catch. All 437 affected grader tests and 477 product CPU checks pass, with three existing dependency skips. A real-source replay of 192 fixed reference-like replies preserves every old/new grade: 191 positive and one existing negative inequality-format case. No task is edited or filtered. Both fresh asynchronous arms use this identical repair and lock. The other three shared Marin package trees, package versions, wheels and vLLM pin remain unchanged. Completed controls at the prior grader revision stay a separate timing stage. This replay does not establish generated-answer quality or learning benefit.

The SC kernel is byte-identical to the baseline. The current independent FP32 scalar replay matches within 1.63e-9; FP64 evaluation of the same quantized heads differs by up to 5.40e-5. An earlier artificial warmup at the tiny-tail floor differed by 0.002755. Near-unit head mass makes the modeled tail sensitive to FP32 rounding. No kernel, floor, tolerance or K changed. This scalar precision limit does not establish parameter-gradient impact or learning benefit.

Measure whole cycles after warmup and record components, memory and uncertainty. Report asynchronous throughput, learner waiting, source age, response variation and actual probe cadence. A 32-position export limit does not bound engine collection, and one head request can amplify work across a mixed decode batch. CPU representation and Ray round-trip timings cannot establish whole-cycle savings. New learning trials, checkpoint recovery and model-parameter gradient campaigns require separate scope.
