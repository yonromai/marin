"""Preflight the unsubmitted Interactive proposal; explicit approval is still required."""

import argparse
import hashlib
import json
from pathlib import Path

import yaml
from omegaconf import OmegaConf

from cloud.iris.iris_backend import _iris_submission_state, launch
from cloud.iris.launch_config import load_launch_config
from rigging.filesystem.s3_compat import configure_coreweave_s3
from skyrl_train.utils.utils import validate_batch_sizes


parser = argparse.ArgumentParser()
parser.add_argument("--config", type=Path, required=True)
parser.add_argument("--receipt", type=Path, required=True)
parser.add_argument("--timeout-seconds", type=int, default=10800)
args = parser.parse_args()
configure_coreweave_s3()
config = load_launch_config(args.config)
validate_batch_sizes(config.skyrl)
raw = OmegaConf.to_container(config, resolve=True, throw_on_missing=True)
state = _iris_submission_state(args.config, config)
assert state.dry_run and not state.no_wait
result = launch(state, expected_launcher_commit=raw["runtime"]["launcher_commit"])
assert result.job_state == "prepared" and result.exit_code == 0
trainer = raw["skyrl"]["trainer"]
generator = raw["skyrl"]["generator"]
short = raw["skyrl"]["trainer"]["score_centering_performance"]["workload"] == "qwen"
assert raw["iris"]["allocation"]["num_nodes"] == (2 if short else 5)
assert raw["iris"]["allocation"]["gpus_per_node"] == 8
assert not short and raw["iris"]["priority"] == "interactive"
assert raw["iris"]["max_retries"] == 0 and raw["iris"]["timeout"] == args.timeout_seconds
parallel = trainer["policy"]["megatron_config"]
for key, value in {
    "tensor_model_parallel_size": 1,
    "pipeline_model_parallel_size": 1 if short else 2,
    "context_parallel_size": 1,
    "expert_model_parallel_size": 1 if short else 8,
}.items():
    assert parallel[key] == value, (key, parallel[key])
assert trainer["policy"]["sequence_parallel_size"] == 1
receipt = {
    "config": str(args.config),
    "sha256": hashlib.sha256(args.config.read_bytes()).hexdigest(),
    "run": raw["run"],
    "runtime": {k: raw["runtime"][k] for k in ("launcher_commit", "profile", "entrypoint", "training_type")},
    "iris": raw["iris"],
    "placement": trainer["placement"],
    "parallelism": parallel,
    "performance": trainer["score_centering_performance"],
    "sampling": generator["sampling_params"],
    "generator": {k: v for k, v in generator.items() if k in (
        "num_inference_engines", "inference_engine_tensor_parallel_size", "weight_sync_backend",
        "gpu_memory_utilization", "max_model_len", "max_num_batched_tokens", "max_num_seqs",
    )},
    "rollout_buffer": trainer["rollout_buffer"],
    "algorithm": trainer["algorithm"],
    "model": raw["inputs"]["model"],
    "declared_context_budget": yaml.safe_load(args.config.read_text())["skyrl"]["context_budget"],
    "batch_validation": True,
    "native_role_and_allocation_validation": True,
    "full_backend_dry_run": True,
    "submission": False,
    "proposal_only": True,
    "requires_explicit_user_approval": True,
    "current_Interactive_node_cap": 4,
    "proposed_Interactive_node_cap": 5,
}
args.receipt.write_text(json.dumps(receipt, indent=2, allow_nan=False) + "\n")
print(json.dumps({"receipt": str(args.receipt), "prepared": True}))
