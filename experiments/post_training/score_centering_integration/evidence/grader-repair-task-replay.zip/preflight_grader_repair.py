# Copyright The Marin Authors
# SPDX-License-Identifier: Apache-2.0
"""Compare actual selected task graders around the scalar validation repair."""

import argparse
import hashlib
import importlib.metadata
import json
import math
from collections import Counter
from pathlib import Path

import pyarrow.parquet as pq
from omegaconf import OmegaConf
from rolloutengine.contracts import ModelTurn
from taskcompendium.grading_result import Outcome

from cloud.iris.launch_config import load_launch_config
from skyrl_gym.answer_tasks import grade_aime, grade_gsm8k, grade_reasoning_gym, ground_truth
from skyrl_gym.envs.reasoning_gym.scoring import normalize_ground_truth
from skyrl_gym.source_task import session_parameters
from skyrl_train.dataset.tasks import source_row_task


def turn(text):
    return ModelTurn(message={'role': 'assistant', 'content': text}, text=text, prompt_token_ids=(1,),
                     response_token_ids=(2,) * 64, logprobs=None, stop_reason='stop',
                     metadata={'generation_token_budget': 4096})


parser = argparse.ArgumentParser()
parser.add_argument('--config', type=Path, required=True)
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--variant', choices=['baseline', 'repaired'], required=True)
args = parser.parse_args()
assert not args.output.exists()
cfg = load_launch_config(args.config).skyrl
source_sha = hashlib.sha256(args.source.read_bytes()).hexdigest()
assert source_sha == cfg.trainer.score_centering_performance.source_data_sha256
selected = list(cfg.trainer.score_centering_performance.source_rows)
rows = pq.read_table(args.source).to_pylist()
by_campaign = {row['campaign_source_row']: (index, row) for index, row in enumerate(rows)}
environments = OmegaConf.to_container(cfg.environment.task_sessions, resolve=True)
graders = {'aime': grade_aime, 'gsm8k': grade_gsm8k, 'reasoning_gym': grade_reasoning_gym}
b = chr(92)
malformed = b + 'sqrt{' + b + 'begin{pmatrix}1 & 2' + b * 2 + '3 & 4' + b + 'end{pmatrix}}'
results = []
for campaign in selected:
    index, row = by_campaign[campaign]
    lowered = source_row_task(row, index, source_name=str(args.source), environment_configs=environments)
    parameters = session_parameters(lowered.task)
    expected = ground_truth(parameters.extras)
    environment = row['env_class']
    if environment == 'aime':
        answer = 'Answer: ' + expected
    elif environment == 'gsm8k':
        answer = '#### ' + expected
    else:
        answer = json.loads(normalize_ground_truth(expected))['entry']['answer']
    transition = graders[environment](turn(answer), parameters.config, parameters.extras)
    assert transition.grade.status is Outcome.GRADED and math.isfinite(transition.grade.reward)
    result = {'campaign_source_row': campaign, 'source_row': index, 'session': environment,
              'uid': lowered.task.id, 'reference_reply_grade': transition.grade.reward,
              'reference_reply_reward': transition.reward,
              'reference_reply_prediction': transition.grade.diagnostics.get('prediction')}
    if environment == 'aime' and args.variant == 'repaired':
        adverse = grade_aime(turn('Answer: ' + b + 'boxed{' + malformed + '}'), parameters.config, parameters.extras)
        assert adverse.grade.status is Outcome.GRADED and adverse.grade.reward == -1.0, (campaign, adverse)
        result['nonscalar_candidate_grade'] = adverse.grade.reward
    results.append(result)
    if len(results) % 32 == 0:
        print(json.dumps({'completed_groups': len(results), 'variant': args.variant}), flush=True)
metadata = json.loads(importlib.metadata.distribution('marin-verifyit').read_text('direct_url.json'))
source_commit = metadata['vcs_info']['commit_id']
assert source_commit == ('5ef1e703d3bae94d510d8cf3f50d902958e10d20' if args.variant == 'repaired' else 'b3206ac1c46cee3079441f394b5a6a13bb923d0e')
output = {'config': args.config.name, 'variant': args.variant, 'source_sha256': source_sha,
          'source_groups': len(rows), 'campaign_source_rows': selected, 'selected_groups': len(results),
          'sessions': dict(Counter(row['session'] for row in results)),
          'reference_reply_grade_counts': dict(Counter(row['reference_reply_grade'] for row in results)),
          'nonscalar_candidate_grades': sum('nonscalar_candidate_grade' in row for row in results),
          'grader_source_commit': source_commit,
          'versions': {name: importlib.metadata.version(name) for name in ('marin-verifyit', 'math-verify', 'latex2sympy2-extended', 'sympy')},
          'results': results,
          'scope': 'Actual source lowering and direct real graders with reference-like replies. These may expose existing extraction limits; only old/new parity is claimed. No GPU generation, throughput or learning claim.'}
assert len(results) == 192
args.output.write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps({key: output[key] for key in ('variant', 'selected_groups', 'reference_reply_grade_counts', 'nonscalar_candidate_grades', 'grader_source_commit')}))
