from pathlib import Path
import json, hashlib, ast, subprocess

A = Path('/home/romain/data/sessions/devbox/codex/01a146a3-0842-7e33-a843-b6727eec150d/artifacts/integration-20261019')
root = Path('/home/romain/work/marin-community/MarinSkyRL')
base = root / 'score-centering-integration-baseline-grader-01a146a3'
candidate = root / 'score-centering-integration-workers-grader-01a146a3'
file = 'skyrl-train/skyrl_train/entrypoints/score_centering_performance.py'
assert (base/file).read_bytes() == (candidate/file).read_bytes()
for name in ('uv.lock', 'pyproject.toml'):
    assert (base/name).read_bytes() == (candidate/name).read_bytes()

def source(commit, path):
    return subprocess.check_output(['git', '-C', str(base), 'show', commit+':'+path])

def functions(raw):
    return {node.name: ast.dump(node, include_attributes=False) for node in ast.walk(ast.parse(raw))
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}

proof = {'runtime_commits': {'baseline': 'dffd2c4b318bad910e532dea19f05a3cc1f9916e',
                             'candidate': '56e187219994288b50463d8505f822329beb0795'},
         'product_candidate': 'c36e8594cbbbe55362945debfa6f75887a96361f',
         'grader_patch': '5ef1e703d3bae94d510d8cf3f50d902958e10d20',
         'lock_sha256': hashlib.sha256((base/'uv.lock').read_bytes()).hexdigest(),
         'matched_benchmark_file': file, 'benchmark_file_sha256': hashlib.sha256((base/file).read_bytes()).hexdigest(),
         'measurement_methods_unchanged': {}}
current = functions((base/file).read_bytes())
for commit in ('3b5de0c201a8ab7034aa53d9be3645d1e5372a8b', '92d057c561b0893a3d922e42f221eb8d5b1e68fb'):
    prior = functions(source(commit, file))
    names = ('native_window', 'asynchronous_comparison', 'native_periodic_comparison', 'settings', 'get_train_dataset')
    assert all(current[name] == prior[name] for name in names)
    assert (base/'skyrl-train/skyrl_train/trainer.py').read_bytes() == source(commit, 'skyrl-train/skyrl_train/trainer.py')
    proof['measurement_methods_unchanged'][commit] = list(names)
marin = Path('/home/romain/work/marin-community/marin/score-centering-aime-grader-01a146a3')
old = 'b3206ac1c46cee3079441f394b5a6a13bb923d0e'
fix = proof['grader_patch']
trees = {}
for package in ('rolloutengine', 'shellbox', 'taskcompendium'):
    original = subprocess.check_output(['git', '-C', str(marin), 'rev-parse', old+':lib/'+package], text=True).strip()
    updated = subprocess.check_output(['git', '-C', str(marin), 'rev-parse', fix+':lib/'+package], text=True).strip()
    assert original == updated
    trees[package] = original
proof['other_Marin_package_trees_identical'] = trees
proof['Marin_patch_changed_files'] = subprocess.check_output(['git', '-C', str(marin), 'diff', '--name-only', old, fix], text=True).splitlines()
changed = subprocess.check_output(['git', '-C', str(base), 'diff', '--name-only',
                                  '87f13fcd82b4677545816e0789c685d10cf051a0', proof['product_candidate'],
                                  '--', 'skyrl-train', 'skyrl-gym'], text=True).splitlines()
assert not changed
proof['product_code_tree_unchanged_since_native_floor_qualification'] = True
(A/'matched-grader-runtime-proof.json').write_text(json.dumps(proof, indent=2)+'\n')
print(json.dumps(proof))
