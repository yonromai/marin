# Final Goal Review: Score-Centering Integration

- **Review Kind**: GOAL
- **Reviewer**: Antigravity (`agy`, model: Gemini 3.8 Flash High)
- **Reviewed Worktree**: `/home/romain/work/marin-community/MarinSkyRL/score-centering-integration-01a146a3`
- **Product Commit Range**: `964a602e995b16943dc34db036d25d2b7c5b7310`..`ef1adaf25ad2aedfb346bb71aeaa92e0d9cd6212` (HEAD)
- **Evidence Checkout**: `/home/romain/work/marin-community/marin/score-centering-integration-01a146a3` at immutable measurement HEAD `622314c9bf1d689230fb0717dc536e0c3d907b5a`
- **Runtime Worktrees / Heads**:
  - Baseline Async: `/home/romain/work/marin-community/MarinSkyRL/score-centering-integration-baseline-grader-01a146a3` at `dffd2c4b318bad910e532dea19f05a3cc1f9916e`
  - Candidate Async: `/home/romain/work/marin-community/MarinSkyRL/score-centering-integration-workers-grader-01a146a3` at `56e187219994288b50463d8505f822329beb0795`
  - Grader Repair: `/home/romain/work/marin-community/marin/score-centering-aime-grader-01a146a3` at `5ef1e703d3bae94d510d8cf3f50d902958e10d20`
- **Delivery Artifacts**:
  - Product Documentation: [docs/score-centering.md](file:///home/romain/work/marin-community/MarinSkyRL/score-centering-integration-01a146a3/docs/score-centering.md)
  - PR 968 Snapshot: `/home/romain/data/sessions/devbox/codex/01a146a3-0842-7e33-a843-b6727eec150d/artifacts/integration-20261019/pr968-final-async-body.md`
  - Echo Design 608 Snapshot: `/home/romain/data/sessions/devbox/codex/01a146a3-0842-7e33-a843-b6727eec150d/artifacts/integration-20261019/echo-design608-final-summary.md`
  - CI Status: GitHub Actions run `39427943026` on HEAD `ef1adaf2` (terminal, 6/6 checks successful: `iris_launcher_tests`, `lint`, `skyrl_train_macos_install`, `skyrl_gym_tests`, `skyrl_train_tests`, `infra_tests`).

---

## Executive Summary

**Verdict: Supported. No material findings.**

The engineering integration goal—to make score centering (SC) as fast as practical while preserving exact correctness through existing vLLM engine interfaces, and establishing complete controlled and real-reward asynchronous performance on Snowball—has been fully achieved and validated against all four required outcomes and resource boundaries:

1. **Root cause isolation**: Demonstrated that the previously observed 45.5%–53.0% SC adoption overhead stemmed from candidate chat object serialization, detokenization, and parsing (`129 * response_length` Python objects per request across Ray).
2. **Interface integration**: Implemented a request-scoped wrapper (`CompactChatEngineClient`) calling vLLM's public `generate` interface with `flat_logprobs=True` and `logprobs=top_k+1`, bypassing display logprob construction and packing owned NumPy arrays (`int32` IDs, `float32` scores) directly into internal Ray response metadata. Full exactness (tokens, text, temperatures, causal positions, masks, per-token source stamps, token-ID tie ordering, and display floor `-9999.0`) is preserved without modifying vLLM internals.
3. **Controlled cost reduction**: On 5x8 H100 Snowball controls on RNO, serialized SC cycle time decreased by **29.57%** (from 88.38s to 62.25s), and SC adoption overhead over ordinary TIS dropped from **53.00%** to **9.27%** (descriptive interval: 7.40% to 11.17%). Exclusive batch admission wait dropped from 71.69s to 45.42s.
4. **Real-reward asynchronous validation**: Executed a complete paired 67-update asynchronous comparison on RNO with real task rewards, applied optimizer updates, and nonzero gradients across all 64 real-reward updates. Response throughput increased by **128.28%** (from 3007 to 6864 response tokens/s), while updates/hour decreased slightly by **13.21%** (from 118.15 to 102.54 updates/h) due to a substantial increase in stochastic response length (mean 1882.82 vs 715.79 tokens).
5. **Operational rigor**: All 19 actual GPU submissions are terminal, absent, and accounted for (244.44 H100-hours controller terminal proxy, 315.09 H100-hours verified absence bound). Both clusters (`cw-rno2a` and `cw-us-east-02a`) are confirmed completely idle with 0 active jobs, 0 active Pods, and 0 active Kueue workloads.

---

## Detailed Evaluation by Required Outcome

### 1. Cost Location in the Native Path (Supported)
- **Data flow analysis**: The integration correctly distinguishes between the authors' single-node sequential sampler/trainer (which batches GPU top-k across 32 decode steps and reshards tensors in device memory) and MarinSkyRL's distributed disaggregated architecture (separate vLLM inference node, Ray RPC transport, S3 rollout buffer, CPU tensor collation, and D2H/H2D transfers to Megatron learner GPUs).
- **Measurement evidence**: Retained CPU benchmarks (`evidence/cpu-native-chat-cost-floor.json`) and profiled Snowball warmup showed that constructing Pydantic chat objects consumed ~3.41s of CPU representation and generated ~19.2 MB payloads per 4096-token response, compared to 0.065s and 4.2 MB for numeric NumPy arrays. The profiled warmup confirmed the complete elimination of 174,080 per-token formatter calls per cycle.

### 2. Integration Implementation and Equivalence (Supported)
- **vLLM Engine Boundary**:
  - `skyrl-train/skyrl_train/inference_engines/vllm/compact_chat.py` introduces `CompactChatEngineClient`, wrapping `engine` without subclassing, monkey-patching, or modifying vLLM internals.
  - vLLM remains pinned at `39e62869693c46402b1a95fde4fc55ca1aab9ae1`.
  - Chat rendering, message parsing, and tool calls remain handled by vLLM's public chat pipeline.
  - When internal native chat requests specify `response_topk_width`, `AsyncVLLMInferenceEngine._chat_completion` updates the request with `logprobs=False, top_logprobs=0` (suppressing chat display logprobs) and opens a `capture(compact_top_k)` context.
  - In `generate()`, `sampling_params.clone()` is set to `logprobs = top_k + 1` and `flat_logprobs = True`.
- **Tie Ordering and Display Floor Parity**:
  - `select_flat_chat_response_topk` in `response_topk.py` collects $K+1$ candidates (129 for $K=128$) and applies `minimum_logprob = -9999.0`, reproducing the pinned chat formatter's score floor.
  - When the sampled token is duplicated in the top-$K+1$, the final candidate is retained; when outside, the final candidate is dropped (`-np.inf`), exactly replicating the chat display truncation slot.
  - Lexicographical sort `np.lexsort((ids, -order_scores))` preserves stable descending score order and ascending token-ID tie resolution.
  - Verified by 32 CPU BF16 tie-boundary cases (`chat-collection-width-tie-proof.json`) and 4 synthetic contract cases (`chat-floor-after-proof.json`).
- **Concurrency, Lifecycles, and Aborts**:
  - `ContextVar` isolates concurrent request captures across async tasks, validated by `test_concurrent_compact_and_ordinary_chats_keep_separate_heads`.
  - Generator lifecycle is managed via `contextlib.aclosing()`, and `_id_only_requests` are cleared in `finally`.
  - Aborts before the first token yield zero-row arrays of shape `(0, K)`, preserving array shapes and token alignment across retries (`test_abort_before_first_token_keeps_empty_aligned_evidence` and `test_chat_completion_retry_accumulates_and_sends_continuations`).

### 3. Complete Controlled Snowball Cost (Supported)
- **Workload**: 5x8 H100 nodes on RNO (4 Megatron learner nodes, 1 vLLM inference node). Matched 174,080 response tokens, 164,484 loss tokens, 128 responses through length 4096. 18 applied updates per arm, 2 measured rotating cycles after warmup.
- **Results**:
  - SC cycle duration: **88.381s** (chat objects) $\rightarrow$ **62.248s** (numeric arrays) = **29.57% reduction** (descriptive interval: 19.51% to 38.38%).
  - Adoption overhead above ordinary TIS: **53.00%** $\rightarrow$ **9.27%** (descriptive interval: 7.40% to 11.17%).
  - Batch admission wait: **71.69s** $\rightarrow$ **45.42s** (inclusive of generation and Ray handoff).
  - Memory: Peak learner allocated memory remained identical at 55.53 GiB; inference peak was identical at 58.31 GiB.
- **Probe Overhead**:
  - Modeled interval-10 probe overhead is 0.166% (570.64s between observations).
  - Wide descriptive interval (-15.84% to 19.23%) is properly noted as not establishing a strict sub-1% ceiling; default probe parameters (`interval=10, topk=128, tokens_per_response=32`) are appropriately retained.

### 4. Real-Reward Asynchronous Snowball Comparison (Supported)
- **Workload**: 67 applied updates from original SFT checkpoint (3 calibration, 6 periodic, 58 asynchronous) with real task rewards, applied optimizer updates, full-batch admission, source age limit 4, and 64 in-flight groups.
- **Grader Repair**:
  - Prior preemption/failure on attempt `a3` traced to SymPy `TypeError` on matrix roots in AIME solutions.
  - Narrow repair in `verifyit` (`5ef1e703d3bae94d510d8cf3f50d902958e10d20`) adds `value.is_commutative` check prior to scalar finiteness validation.
  - Verified across 192 task rows (`grader-repair-task-parity.json`) with 100% grade parity, and 437 unit tests passing. Both baseline and candidate async arms shared this identical repair.
- **Asynchronous Throughput and Overlap**:
  - SC Response Tokens/s: **3007** (baseline) $\rightarrow$ **6864** (candidate) (+128.28%).
  - SC Updates/h: **118.15** $\rightarrow$ **102.54** (-13.21%).
  - Mean response length: **715.79** tokens $\rightarrow$ **1882.82** tokens (2.63x longer).
  - Exclusive walls: Batch assembly fell from 6.92s to 2.46s; weight publication fell from 12.32s to 6.24s. Learner wait rose from 1.49s to 16.62s as generation dominated the longer responses.
  - Nonzero gradients: Confirmed 10/10 measured SC updates and 64/64 real-reward updates had nonzero gradients with zero skips in both arms.
  - Methodological integrity: The report and documentation explicitly decline to claim a causal training speedup from tokens/s, detailing how stochastic response length differences and asynchronous pipeline overlapping interact.

---

## Boundaries, Constraints, and Resource Accounting

1. **vLLM Dependency**:
   - Pinned at `39e62869693c46402b1a95fde4fc55ca1aab9ae1`. No fork patches, upgrades, monkey-patches, or subclassing of vLLM internals were added.
2. **Cluster and Priority Constraints**:
   - Only `cw-rno2a` and `cw-us-east-02a` clusters were used.
   - Interactive usage was limited strictly to 2 nodes for Qwen qualification ($\le 4$ node cap).
   - Snowball runs were submitted exclusively at `BATCH` priority. The r12 proposal to use Interactive priority was kept unapproved and unsubmitted, and r13 successfully acquired BATCH nodes on RNO.
3. **Finite Deadlines and Automatic Retries**:
   - Zero automatic retries were enabled on any submission. Every attempt was declared via finite protocol revisions with 6-hour queue-inclusive deadlines.
4. **Allocation Accounting and Final State**:
   - Total attempts: Exactly 19 actual submissions (12 Snowball baseline, 4 Snowball candidate, 3 Qwen candidate).
   - Compute consumption: 244.44 H100-hours to controller terminal; 315.09 H100-hours upper bound through verified provider absence.
   - Shutdown verification: `evidence/final-async-shutdown-summary.json` confirms 0 active jobs, 0 active Pods, 0 Kueue workloads, and 0 local launchers across both clusters.

---

## Material Findings

**There are NO material findings (blockers, bugs, or unaddressed gaps).**

---

## Preserved Observations and Technical Context (Non-Blockers)

1. **Stochastic Response Length in Asynchronous Execution**:
   - In the real-reward asynchronous runs, candidate responses were significantly longer than baseline responses (1883 vs 716 tokens in SC; 2187 vs 1116 tokens in ordinary TIS).
   - Because generation time scales with response length, the candidate learner spent more time waiting for the generation buffer (47.34% vs 4.88% wait fraction), lowering updates/hour despite more than doubling response token throughput.
   - *Status*: Properly documented in `docs/score-centering.md` and `README.md`. No causal speedup or learning claim is made, which maintains full scientific rigor.
2. **FP32 Tail Subtraction Rounding Near Unit Head Mass**:
   - When the captured head contains nearly 100% of the probability mass, $(1 - \sum P)$ in FP32 subtraction can produce tiny negative or rounding-sensitive tail estimates.
   - Scalar replay showed differences up to 0.002755 between FP32 and FP64 in an artificial tiny-tail warmup case (`evidence/qwen-floor-a2-probe-precision.json`).
   - *Status*: This is a preserved property of the baseline SC kernel (which is byte-identical to the prior goal). It does not affect parameter gradients or introduce regressions.
3. **AIME Grader Matrix-Root Handling**:
   - The scalar grading fix in `marin-verifyit` commit `5ef1e703` gracefully handles non-commutative matrix expressions before SymPy evaluation.
   - *Status*: Regression tests and task parity checks (192 rows) confirm identical grades on all existing references. Both async arms used the identical repaired lock and grader revision.

---

## Scope and Evidence Inspection Summary

The following artifacts and codebases were directly inspected:
- **Product Tree**: `skyrl-train/skyrl_train/inference_engines/vllm/compact_chat.py`, `vllm_engine.py`, `inference_engine_client.py`, `response_topk.py`, `trajectory_runners/model_clients.py`, `pyproject.toml`, `uv.lock`, and associated CPU test suites.
- **Evidence Files**: `experiments/post_training/score_centering_integration/` including `README.md`, `allocation-accounting.json`, `snowball-stage-attempts.json`, `snowball-staged-protocol-r13.json`, `evidence/final-async-shutdown-summary.json`, `evidence/snowball-controlled-cost-matched-rno.json`, `evidence/snowball-asynchronous-matched-rno.json`, `evidence/matched-grader-runtime-proof.json`, `evidence/grader-repair-task-parity.json`, `evidence/chat-collection-width-tie-proof.json`, `evidence/chat-floor-after-proof.json`, `evidence/qwen-floor-a2-probe-precision.json`, and raw ZIP reports.
- **Grader Worktree**: `/home/romain/work/marin-community/marin/score-centering-aime-grader-01a146a3` at commit `5ef1e703d3bae94d510d8cf3f50d902958e10d20`.
- **Runtime Worktrees**: Verified HEADs of `/home/romain/work/marin-community/MarinSkyRL/score-centering-integration-baseline-grader-01a146a3` (`dffd2c4b`) and `/home/romain/work/marin-community/MarinSkyRL/score-centering-integration-workers-grader-01a146a3` (`56e18721`).
- **External PR and CI**: PR 968 metadata/comments and GitHub Actions workflow run `39427943026` on HEAD `ef1adaf2` (all 6 checks verified green).

*No evidence was inaccessible or withheld from inspection.*
