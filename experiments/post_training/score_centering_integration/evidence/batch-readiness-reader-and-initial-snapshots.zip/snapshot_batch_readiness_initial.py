"""Read this five-node BATCH job's GPU fit, quota and higher-priority queue."""

import argparse
import json
import subprocess
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import yaml

parser = argparse.ArgumentParser()
parser.add_argument('--cluster', choices=['cw-rno2a', 'cw-us-east-02a'], required=True)
parser.add_argument('--config-root', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
config = yaml.safe_load((args.config_root / f'{args.cluster}-client.yaml').read_text())
provider = config['platform']['coreweave']
base = ['kubectl', '--kubeconfig', str(Path(provider['kubeconfig_path']).expanduser()), '--context', provider['kube_context']]
queue_name = config['kubernetes_provider']['kueue']['cluster_queue']


def read(arguments):
    return json.loads(subprocess.check_output(base + arguments + ['-o', 'json'], timeout=25))


items = read(['get', 'nodes,pods', '--all-namespaces'])['items']
pods = [p for p in items if p['kind'] == 'Pod']
pod_by_uid = {p['metadata']['uid']: p for p in pods}
workloads = read(['-n', 'iris', 'get', 'workloads.kueue.x-k8s.io'])['items']
queue = read(['get', 'clusterqueue', queue_name])
lower_owners = set()
lower_quota = defaultdict(float)
higher_pending = []
by_priority = defaultdict(lambda: {'admitted_gpus': 0, 'pending_gpus': 0, 'workloads': 0})
exclusions = defaultdict(int)


def gpu_requests(spec):
    def gpu(container):
        return float(container.get('resources', {}).get('requests', {}).get('nvidia.com/gpu', 0))
    return max(sum(gpu(c) for c in spec.get('containers', [])), max((gpu(c) for c in spec.get('initContainers', [])), default=0))


for w in workloads:
    spec, status, metadata = w['spec'], w.get('status', {}), w['metadata']
    conditions = status.get('conditions', [])
    if spec.get('active') is False or metadata.get('deletionTimestamp') or any(c['type'] == 'Finished' and c['status'] == 'True' for c in conditions):
        exclusions['finished_inactive_or_deleting'] += 1
        continue
    owners = [r for r in metadata.get('ownerReferences', []) if r.get('kind') == 'Pod']
    if owners and all(r['uid'] in pod_by_uid and pod_by_uid[r['uid']].get('status', {}).get('phase') in ['Succeeded', 'Failed'] for r in owners):
        exclusions['all_owners_terminal'] += 1
        continue
    priority = spec.get('priority')
    priority = int(priority) if priority is not None else None
    admitted = any(c['type'] == 'Admitted' and c['status'] == 'True' for c in conditions)
    reserved = any(c['type'] == 'QuotaReserved' and c['status'] == 'True' for c in conditions)
    admission = status.get('admission', {})
    requested = sum(p.get('count', 1) * gpu_requests(p.get('template', {}).get('spec', {})) for p in spec.get('podSets', []))
    aggregate = by_priority[str(priority)]
    aggregate['workloads'] += 1
    if admitted or reserved:
        usage = defaultdict(float)
        for assignment in admission.get('podSetAssignments', []):
            for key in ['nvidia.com/gpu', 'rdma/ib']:
                usage[key] += float(assignment.get('resourceUsage', {}).get(key, 0))
        aggregate['admitted_gpus'] += usage['nvidia.com/gpu']
        if admitted and admission.get('clusterQueue') == queue_name and priority is not None and priority < 2:
            lower_owners.update(r['uid'] for r in owners)
            for key in usage:
                lower_quota[key] += usage[key]
    else:
        aggregate['pending_gpus'] += requested
        if requested > 0 and (priority is None or priority > 2):
            higher_pending.append({'name': metadata['name'], 'uid': metadata['uid'], 'priority': priority, 'requested_gpus': requested})

policy = queue['spec'].get('preemption', {}).get('withinClusterQueue')
can_reclaim_lower = policy == 'LowerPriority'
node_usage = defaultdict(lambda: {'used_gpus': 0, 'nonreclaimable_gpus': 0})
owned = []
for pod in pods:
    if pod.get('status', {}).get('phase') in ['Succeeded', 'Failed']:
        continue
    spec, metadata = pod.get('spec', {}), pod['metadata']
    requested = gpu_requests(spec)
    node = spec.get('nodeName')
    if node:
        node_usage[node]['used_gpus'] += requested
        if not can_reclaim_lower or metadata['uid'] not in lower_owners:
            node_usage[node]['nonreclaimable_gpus'] += requested
    task = metadata.get('annotations', {}).get('iris.task_id', '')
    if task.startswith('/romain/sc-') and '01a146a3' in task:
        owned.append({'task': task, 'pod': metadata['name'], 'phase': pod.get('status', {}).get('phase')})

nodes = []
for n in items:
    if n['kind'] != 'Node' or float(n.get('status', {}).get('allocatable', {}).get('nvidia.com/gpu', 0)) != 8 or 'H100' not in n['metadata'].get('labels', {}).get('nvidia.com/gpu.product', ''):
        continue
    usage = node_usage[n['metadata']['name']]
    ready = any(c['type'] == 'Ready' and c['status'] == 'True' for c in n.get('status', {}).get('conditions', []))
    schedulable = not n.get('spec', {}).get('unschedulable', False)
    nodes.append({'name': n['metadata']['name'], 'ready': ready, 'schedulable': schedulable, **usage, 'taints': n.get('spec', {}).get('taints', [])})

nominal = defaultdict(float)
for group in queue['spec']['resourceGroups']:
    for flavor in group['flavors']:
        for r in flavor['resources']:
            if r['name'] in ['nvidia.com/gpu', 'rdma/ib']:
                nominal[r['name']] += float(r['nominalQuota'])
reserved = defaultdict(float)
for flavor in queue.get('status', {}).get('flavorsReservation', []):
    for r in flavor['resources']:
        if r['name'] in nominal:
            reserved[r['name']] += float(r['total'])
available = {key: nominal[key] - reserved[key] + (lower_quota[key] if can_reclaim_lower else 0) for key in nominal}
free_nodes = sum(n['ready'] and n['schedulable'] and n['used_gpus'] == 0 for n in nodes)
batch_nodes = sum(n['ready'] and n['schedulable'] and n['nonreclaimable_gpus'] == 0 for n in nodes)
active_queue = any(c['type'] == 'Active' and c['status'] == 'True' for c in queue.get('status', {}).get('conditions', []))
ready = active_queue and batch_nodes >= 5 and all(available[k] >= 40 for k in ['nvidia.com/gpu', 'rdma/ib']) and not higher_pending and not owned
summary = {'checked_at': datetime.now(timezone.utc).isoformat(), 'cluster': args.cluster, 'free_whole_gpu_nodes': free_nodes, 'whole_gpu_nodes_available_to_batch': batch_nodes, 'gpu_quota_available_to_batch': available['nvidia.com/gpu'], 'rdma_quota_available_to_batch': available['rdma/ib'], 'higher_priority_pending_gpu_workloads': len(higher_pending), 'ready_for_five_node_batch': ready}
result = {**summary, 'within_queue_preemption_policy': policy, 'queue_active': active_queue, 'nominal_quota': dict(nominal), 'reserved_quota': dict(reserved), 'admitted_lower_priority_quota': dict(lower_quota), 'higher_pending': higher_pending, 'by_priority': dict(by_priority), 'excluded': dict(exclusions), 'owned_active_pods': owned, 'nodes': nodes, 'scope': 'Read-only GPU slot and quota estimate under the current normal LowerPriority policy. Counts only admitted lower-priority owners in the same queue as reclaimable. Excludes finished/inactive/deleting work. Unknown-priority pending GPU work blocks readiness. Node taints, CPU/memory and scheduler timing still constrain actual placement; this is not a reservation or protection from future higher-priority arrivals.'}
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(summary))
